#pragma once
float Scout(const char* temp);